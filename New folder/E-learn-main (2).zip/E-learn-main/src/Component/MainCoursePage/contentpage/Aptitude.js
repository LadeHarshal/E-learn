import React from 'react'

const Aptitude = () => {
  return (
    <div>
      hello manthan
    </div>
  )
}

export default Aptitude
