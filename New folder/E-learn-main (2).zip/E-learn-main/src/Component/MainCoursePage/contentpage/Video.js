// import React from 'react'

// const Video = () => {
//   return (
//     <div>
//     hiii
//     </div>
//   )
// }

// export default Video

// import React from 'react';

// const VideoPlayer = () => {
//   return (
//     <div>
//       <h2>Web Development Course Video</h2>
//       <video width="640" height="360" controls>
//         <source src="/path/to/your/video.mp4" type="video/mp4" />
//         Your browser does not support the video tag.
//       </video>
//     </div>
//   );
// };

// export default VideoPlayer;

// import React from 'react';
//  import './Video.css'; // Import your CSS file

// const VideoPlayer = () => {
//   return (
//     <div className="video-container">
//       <h2 className="video-title">Full Stack Web Development Course Video</h2>
//       <video className="video-player" width="600" height="360" controls>
//         <source src="/path/to/your/video.mp4" type="video/mp4" />
//         Your browser does not support the video tag.
//       </video>
//     </div>
//   );
// };

// export default VideoPlayer;
