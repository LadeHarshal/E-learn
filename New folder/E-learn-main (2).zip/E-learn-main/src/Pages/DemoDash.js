import React from "react";

function DemoDash() {
  return <div>DemoDash</div>;
}

export default DemoDash;
