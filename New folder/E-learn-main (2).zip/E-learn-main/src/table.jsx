import React, { useEffect } from 'react'

function table() {
    useEffect(()=> {
        axios.get('')
    }, [])
  return (
    <div>
        
    </div>
  )
}

export default table
